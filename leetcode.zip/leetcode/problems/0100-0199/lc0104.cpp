// 104. Maximum Depth of Binary Tree — https://leetcode.com/problems/maximum-depth-of-binary-tree/
#include <lc/prelude.hpp>
using namespace std;

class Solution {
public:
    int maxDepth(TreeNode* root) {
        if (!root) return 0;
        return 1 + max(maxDepth(root->left), maxDepth(root->right));
    }
};

int main() {
    TreeNode* root = lc::build_tree("[3,9,20,null,null,15,7]");
    lc::print(lc::to_string(root));        // "[3,9,20,null,null,15,7]"
    lc::print(Solution{}.maxDepth(root));  // 3
    lc::free_tree(root);
}
