#pragma once
// Printing helpers: lc::print(a, b, c) prints space-separated values + newline.
// Handles nested ranges (vector<vector<int>>), pairs, tuples, optionals, bools.

#include <iostream>
#include <optional>
#include <ranges>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <utility>

namespace lc {

namespace detail {
template <typename T> struct is_pair : std::false_type {};
template <typename A, typename B> struct is_pair<std::pair<A, B>> : std::true_type {};

template <typename T> struct is_tuple : std::false_type {};
template <typename... Ts> struct is_tuple<std::tuple<Ts...>> : std::true_type {};

template <typename T> struct is_optional : std::false_type {};
template <typename T> struct is_optional<std::optional<T>> : std::true_type {};
} // namespace detail

template <typename T>
void print_one(std::ostream& os, const T& x) {
    if constexpr (std::is_same_v<T, bool>) {
        os << (x ? "true" : "false");
    } else if constexpr (std::is_convertible_v<const T&, std::string_view>) {
        os << '"' << std::string_view(x) << '"';
    } else if constexpr (std::ranges::range<T>) {
        os << '[';
        bool first = true;
        for (const auto& e : x) {
            if (!first) os << ", ";
            print_one(os, e);   // recursion handles nested containers
            first = false;
        }
        os << ']';
    } else if constexpr (detail::is_pair<T>::value) {
        os << '(';
        print_one(os, x.first);
        os << ", ";
        print_one(os, x.second);
        os << ')';
    } else if constexpr (detail::is_tuple<T>::value) {
        os << '(';
        std::apply([&](const auto&... es) {
            std::size_t i = 0;
            ((os << (i++ ? ", " : ""), print_one(os, es)), ...);
        }, x);
        os << ')';
    } else if constexpr (detail::is_optional<T>::value) {
        if (x) print_one(os, *x);
        else   os << "null";
    } else {
        os << x;
    }
}

// lc::print(1, vec, "hi")  ->  1 [1, 2, 3] "hi"
template <typename... Ts>
void print(const Ts&... xs) {
    std::size_t i = 0;
    ((std::cout << (i++ ? " " : ""), print_one(std::cout, xs)), ...);
    std::cout << '\n';
}

} // namespace lc
